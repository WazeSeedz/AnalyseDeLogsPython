INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:37','http://www.freeradius.org/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:38','http://download.cdn.mozilla.net/pub/firefox/releases/26.0/update/win32/fr/firefox-24.0-26.0.partial.mar');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:38','http://freeradius.org/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:38','http://pagead2.googlesyndication.com/activeview?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:39','http://www.google-analytics.com/__utm.gif?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:43','http://freeradius.org/download.html');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:43','http://www.google-analytics.com/__utm.gif?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:47','http://wiki.freeradius.org/guide/faq');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:47','http://wiki.freeradius.org/custom.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:47','http://wiki.freeradius.org/create/custom.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:51','http://wiki.freeradius.org/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:52','http://wiki.freeradius.org/Home');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:52','http://wiki.freeradius.org/custom.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:52','http://wiki.freeradius.org/create/custom.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:56','http://freeradius.org/doc/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:30:56','http://www.google-analytics.com/__utm.gif?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:31:15','http://www.google.fr/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:09','http://www.google.fr/url?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:10','http://openvpn.se/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:10','http://openvpn.se/standard.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:11','http://pagead2.googlesyndication.com/pagead/expansion_embed.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:12','http://googleads.g.doubleclick.net/pagead/ads?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:12','http://googleads.g.doubleclick.net/pagead/ads?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:12','http://pagead2.googlesyndication.com/pagead/images/nessie_icon_chevron_white.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:13','http://www.google.com/pagead/drt/ui');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:14','http://openvpn.se/favicon.ico');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:14','http://www.google.com/pagead/drt/ui');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:15','http://openvpn.se/documentation.html');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:17','http://googleads.g.doubleclick.net/pagead/ads?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:17','http://www.google.com/pagead/drt/ui');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:20','http://openvpn.se/screenshots.html');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:20','http://openvpn.se/images/connect.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:20','http://openvpn.se/images/newmenu.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:20','http://openvpn.se/images/connect-balloon.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:20','http://openvpn.se/images/status.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:20','http://openvpn.se/images/proxy.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:20','http://openvpn.se/images/changepsw.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:22','http://googleads.g.doubleclick.net/pagead/ads?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:22','http://googleads.g.doubleclick.net/pagead/ads?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:23','http://www.google.com/pagead/drt/ui');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:24','http://www.google.com/pagead/drt/ui');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:29','http://openvpn.se/links.html');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:30','http://googleads.g.doubleclick.net/pagead/ads?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:32:31','http://www.google.com/pagead/drt/ui');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:13','http://www.google.fr/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:25','http://www.google.fr/url?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:26','http://openvpn.net/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:27','http://openvpn.net/media/system/js/core.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:27','http://openvpn.net/media/system/js/caption.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:27','http://openvpn.net/templates/telethra/css/suckerfish.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:27','http://openvpn.net/templates/telethra/favicon.ico');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:27','http://openvpn.net/templates/telethra/css/template.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/media/system/js/mootools-core.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/jquery-1.7.1.min.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-vpnsevice-heading.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-twitter.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-vpnsolution-heading.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-Learn-more.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-Service-botbox.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-vpnsolution-bot.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-vpncommunity-heading.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-vpncommunity-bot.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/images/icon-android.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/images/icon-ios.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-appleicon.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:28','http://openvpn.net/templates/telethra/images/OP-window7icon.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:29','http://www.google-analytics.com/__utm.gif?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:29','http://openvpn.net/templates/telethra/img/bg-wholepage.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:29','http://openvpn.net/templates/telethra/img/ovpntech_logo-s.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:29','http://openvpn.net/templates/telethra/images/OP-Services-bgbox.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:29','http://openvpn.net/templates/telethra/images/OP-foottop.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:32','http://openvpn.net/templates/telethra/images/OP-Services-hover.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:52','http://openvpn.net/index.php/open-source.html');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:54','http://openvpn.net/modules/mod_roknavmenu/themes/fusion/css/fusion.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:54','http://openvpn.net/modules/mod_rokajaxsearch/css/rokajaxsearch.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:54','http://openvpn.net/modules/mod_rokajaxsearch/themes/blue/rokajaxsearch-theme.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:54','http://openvpn.net/modules/mod_roknavmenu/themes/fusion/js/sfhover.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:54','http://openvpn.net/modules/mod_rokajaxsearch/js/rokajaxsearch.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:55','http://openvpn.net/media/system/js/mootools-more.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:55','http://openvpn.net/images/openvpn_icon_navy_40.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:56','http://www.google-analytics.com/__utm.gif?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:56','http://openvpn.net/templates/telethra/img/bg-tab.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:56','http://openvpn.net/modules/mod_rokajaxsearch/themes/blue/search-icon.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:56','http://openvpn.net/modules/mod_roknavmenu/themes/fusion/images/level3-parent.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:56','http://openvpn.net/modules/mod_roknavmenu/themes/fusion/images/level2-parent.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:56','http://openvpn.net/modules/mod_roknavmenu/themes/fusion/images/top-light.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-23 11:33:56','http://openvpn.net/templates/telethra/img/bg-content.png');
