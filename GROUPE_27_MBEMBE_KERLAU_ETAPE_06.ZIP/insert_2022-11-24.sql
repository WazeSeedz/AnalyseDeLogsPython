INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:07','http://www.lequipe.fr/Quotidien/v2/img/arrow_offre.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:07','http://static.lequipe.fr/Quotidien/une/93/une30102013.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:07','http://www.lequipe.fr/Quotidien/v2/img/10article.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:07','http://www.lequipe.fr/Quotidien/v2/img/sprite.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:07','http://static.lequipe.fr/Quotidien/une/93/une05112013.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:07','http://www.lequipe.fr/Quotidien/v2/img/bg-papier.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:07','http://www.lequipe.fr/Quotidien/v2/img/premium.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:07','http://www.lequipe.fr/Quotidien/v2/img/visuel2.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:08','http://www.lequipe.fr/club/compte/ajax/quoti.php');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:08','http://mmtro.com/p?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:08','http://r.turn.com/r/beacon?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:09','http://d2yp9b3a29g3i2.cloudfront.net/ergotest/8e296a067a.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:09','http://mmtro.com/seg/6546622.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:09','http://mmtro.com/sync.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:10','http://static.content-square.net/mousetest/lequipe/mousetest.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:11','http://ib.adnxs.com/seg?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:11','http://ib.adnxs.com/getuid?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:11','http://at.alenty.com/trk/1?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:11','http://mmtro.com/s?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:11','http://mmtro.com/s?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:23','http://www.cnet.com/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:25','http://asset1.cbsistatic.com/cnwk.1d/cb1383771027000/html/rb/js/tron/Build/Filelists/2000/2000.1.0.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:25','http://asset3.cbsistatic.com/cnwk.1d/cb1383773313000/css/rb/Build/global/site1.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:25','http://i.i.cbsi.com/cnwk.1d/css/rb/Build/global/ie8.css');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:25','http://asset1.cbsistatic.com/cnwk.1d/cb1383773315000/css/rb/Build/2000/2000.1.1.css?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:25','http://dw.cbsi.com/js/dw.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:25','http://asset2.cbsistatic.com/cnwk.1d/cb1383773313000/css/rb/Build/global/base.css?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:26','http://asset1.cbsistatic.com/cnwk.1d/Ads/common/manta/adFunctionsD-cnet.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:26','http://asset2.cbsistatic.com/cnwk.1d/cb1383771027000/html/rb/js/tron/Build/Filelists/global/loader.js?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:27','http://asset0.cbsistatic.com/cnwk.1d/cb1383771026000/html/rb/js/tron/Build/Filelists/global/base.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:02:29','http://fonts.cnet.com/mna1gzn.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:49','http://ocsp.verisign.com/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:02:49','http://ocsp.verisign.com/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:03:02','http://download.mozilla.org/?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:07','http://asset0.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/35339166-7_620x443_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:07','http://asset2.cbsistatic.com/cnwk.1d/i/tim2/2013/11/05/Lexus%40SEMA2013_05_220x157.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset2.cbsistatic.com/cnwk.1d/i/tim2/2013/09/30/Amazon_Kindle_Fire_HDX_7_35828167-9818_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/11/04/nexus-5-35828372-6361_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset0.cbsistatic.com/cnwk.1d/i/tron/icon/loadMore.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:03:08','http://download.cdn.mozilla.net/pub/mozilla.org/firefox/releases/25.0/update/win32/fr/firefox-24.0-25.0.partial.mar');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/Hue_BR30_low_300x225.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/11/01/top5_1013_NOiPADAir_300x214.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/10/31/142B5325_1_300x214.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset0.cbsistatic.com/cnwk.1d/i/tim2/2013/09/13/Lowers7-NBT_220x157.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/10/29/Barnes_Noble_Nook_GlowLight_35831166_10_220x157.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/amanarange60x43.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/10/31/Google_Nexus_5_35828372-5647_300x225.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset0.cbsistatic.com/cnwk.1d/i/tim2/2013/11/05/sweetie_220x157.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/09/11/dell-venue-tablet-small_60x60.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset2.cbsistatic.com/cnwk.1d/i/tron/icon/icon-sprite.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset0.cbsistatic.com/cnwk.1d/sc/35781409-2-140-0.gif');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/11/05/35567496-Pebble-Watch-orange-2_300x214.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset0.cbsistatic.com/cnwk.1d/i/tron/oreo/rb-logo-footer-pattern.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/10/29/Blackberry_Z30_35827877_12_300x214.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:08','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/35828168_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset1.cbsistatic.com/cnwk.1d/i/tron/hgg/2012/rb-logo-HGG.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/Screen_Shot_2013-11-06_at_12.08.29_PM_140x100.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/MAZDA2%40SEMA2013_2_140x100.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/10/30/Espanol-OSX_mavericks_300x225.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset3.cbsistatic.com/cnwk.1d/i/tron/overlays/Buying-Guides.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset3.cbsistatic.com/cnwk.1d/html/rb/js/omniture/s_code_tm.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset3.cbsistatic.com/cnwk.1d/i/tron/icon/starsSmall.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/11/04/Lowers3-TCL65WT600_300x225.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/Amazon-Kindle-Fire-HDX_8point9-35828168-6501_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/Amazon-Kindle-Fire-HDX_8point9-35828168-6477_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/10/23/2Z9A5136_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset3.cbsistatic.com/cnwk.1d/i/tron/icon/buyingGuideIcons.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:09','http://asset1.cbsistatic.com/cnwk.1d/i/tron/icon/fdScrollerShadow.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:10','http://cdn.clicktale.net/www08/ptc/04aa124c-2298-4540-827a-d9ee84e64713.js');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:03:10','http://www.lequipe.fr/directs/empreintes/checkAll.json');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:11','http://asset1.cbsistatic.com/cnwk.1d/i/tron/cnet/scrollerTopFade.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:11','http://asset1.cbsistatic.com/cnwk.1d/i/tron/oreo/hgg/hgg-global-header-retro.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:11','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/10/30/ot_privates_60x43.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset2.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/youtube_110525-640x480_610x458_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset0.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/Twitter_IPO_1_610x436_220x157.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset2.cbsistatic.com/cnwk.1d/i/tim/2013/01/23/Asus_VivoBook_X202E_35530760_005_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset2.cbsistatic.com/cnwk.1d/i/tim2/2013/10/30/Panasonic_TC-P55ST60_35567256_35566956_35566952_35567256_35566949-18_620x433_60x43.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset1.cbsistatic.com/cnwk.1d/i/tim/2011/08/16/aws2_140x80.JPG');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset2.cbsistatic.com/cnwk.1d/i/tim2/2013/11/06/High-Res-Storefront-%281%29_220x157.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/06/13/Apple_MacBook_Air_13-inch_35781451_10_140x100.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset3.cbsistatic.com/cnwk.1d/i/tim2/2013/11/04/nexus-5-35828372-6437_300x225.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset0.cbsistatic.com/cnwk.1d/i/tim2/2013/11/05/Lowers9-lumen_LED_color_300x225.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/10/30/EA6900_%288%29_300x214.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset1.cbsistatic.com/cnwk.1d/i/tim2/2013/11/05/Hero-logitech_K760.jpg');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset2.cbsistatic.com/cnwk.1d/i/tron/overlays/Overlay-White-220.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset2.cbsistatic.com/cnwk.1d/i/tron/overlays/Key-Line-Shadow-140.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:13','http://asset2.cbsistatic.com/cnwk.1d/i/tron/icon/fdScrollerArrows3.png');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:19','http://www.cnet.com/favicon.ico');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.100','2022-11-24 07:03:19','http://www.cnet.com/html/osdd/cnet.xml');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:04:12','http://www.lequipe.fr/directs/empreintes/checkAll.json');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:04:49','http://ocsp.digicert.com/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:04:49','http://ocsp.digicert.com/');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:05:08','http://download.mozilla.org/?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:05:14','http://www.lequipe.fr/directs/empreintes/checkAll.json');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:05:15','http://download.cdn.mozilla.net/pub/mozilla.org/firefox/releases/25.0/update/win32/fr/firefox-24.0-25.0.partial.mar');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:06:16','http://www.lequipe.fr/directs/empreintes/checkAll.json');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:07:18','http://www.lequipe.fr/directs/empreintes/checkAll.json');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:08:15','http://download.mozilla.org/?');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:08:20','http://www.lequipe.fr/directs/empreintes/checkAll.json');
INSERT INTO PROXY(adresseip,jourheure,URL)
VALUES('192.168.2.1','2022-11-24 07:08:21','http://download.cdn.mozilla.net/pub/mozilla.org/firefox/releases/25.0/update/win32/fr/firefox-24.0-25.0.partial.mar');
